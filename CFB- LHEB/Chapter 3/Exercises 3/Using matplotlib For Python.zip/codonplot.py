#From the Computer for Biologists: Chapter 3
#Chapter Exercise: Section 3.1: Plotting
#Start Codon Frequencies Using Pyplot
#codonplot.py
#Function:  plotStartCodons(length, trials, steps)

from starts import *
#Learning to use a versatile Python module for plotting data
import matplotlib.pyplot as plt

def plotStartCodons(GCcontent, length, trials) :
    ''' This function plotStartCodons(length, trials, steps)   '''
